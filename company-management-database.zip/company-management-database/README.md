# Company Management Database

A structured Oracle SQL and PL/SQL project for modeling and operating a company management system.

## Overview

This project includes a relational schema, sample seed data, analytical queries, database views, PL/SQL business logic, testing scripts, and an Oracle APEX application export.

## Features

- Relational schema for core business entities such as employees, departments, customers, projects, inventory, and orders
- Seed data for realistic testing and demonstration
- Reusable views for reporting and operational visibility
- Analytical SQL queries for workload, sales, and performance insights
- PL/SQL procedures and functions for business operations and validation
- Oracle APEX export for a lightweight front-end application

## Project Structure

```text
company-management-database/
├── README.md
├── .gitignore
└── sql/
    ├── schema.sql
    ├── seed_data.sql
    ├── views.sql
    ├── procedures_and_functions.sql
    ├── analytics_queries.sql
    ├── test_queries.sql
    └── apex_app_export.sql
```

## Recommended Execution Order

1. `sql/schema.sql`
2. `sql/seed_data.sql`
3. `sql/views.sql`
4. `sql/procedures_and_functions.sql`
5. `sql/analytics_queries.sql`
6. `sql/test_queries.sql`

Import `sql/apex_app_export.sql` separately in an Oracle APEX environment if needed.

## Technologies

- Oracle SQL
- PL/SQL
- Oracle APEX

## Notes

- The repository has been cleaned for portfolio presentation.
- Environment-specific metadata has been generalized where appropriate.
- The SQL scripts are organized to make setup and review straightforward.

## License

All rights reserved.
