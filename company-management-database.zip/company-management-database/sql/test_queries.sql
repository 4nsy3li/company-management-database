-- ----------------------------
-- Company Database Project
-- Utility Queries For Testing / Procedures / Functions
-- ----------------------------

-- Test all views
SELECT 'VW_EMPLOYEE_COMPLETE' AS VIEW_NAME, COUNT(*) AS RECORD_COUNT FROM VW_EMPLOYEE_COMPLETE
UNION ALL
SELECT 'VW_PROJECT_ASSIGNMENTS', COUNT(*) FROM VW_PROJECT_ASSIGNMENTS
UNION ALL
SELECT 'VW_CUSTOMER_ORDER_ANALYSIS', COUNT(*) FROM VW_CUSTOMER_ORDER_ANALYSIS
UNION ALL
SELECT 'VW_INVENTORY_STATUS', COUNT(*) FROM VW_INVENTORY_STATUS
UNION ALL
SELECT 'VW_DEPARTMENT_PERFORMANCE', COUNT(*) FROM VW_DEPARTMENT_PERFORMANCE;

-- ----------------------------
-- Company Database Project
-- Test Script For Procedures and Functions
-- ----------------------------

-- Test Functions
SELECT 
    EMP_ID,
    NAME,
    FN_CALCULATE_AGE(DOB) AS AGE,
    FN_GET_EMPLOYEE_HOURS(EMP_ID) AS WEEKLY_HOURS
FROM EMPLOYEE
WHERE ROWNUM <= 5;

-- Test Product Inventory Value
SELECT 
    p.PRODUCT_NAME,
    FN_CALCULATE_INVENTORY_VALUE(p.PRODUCT_ID, 150) AS INVENTORY_VALUE
FROM PRODUCT p
WHERE ROWNUM <= 5;

-- Test Add Employee Procedure
DECLARE
    v_result VARCHAR2(200);
BEGIN
    SP_ADD_EMPLOYEE(
        'Test Employee',
        'NI99999',
        '123 Test Street',
        4500,
        TO_DATE('1990-01-01', 'YYYY-MM-DD'),
        'test@example.com',
        '+44123456789',
        1, -- IT Department
        1, -- First Supervisor
        v_result
    );
    DBMS_OUTPUT.PUT_LINE(v_result);
END;
/

-- Test Salary Update Procedure
DECLARE
    v_result VARCHAR2(200);
BEGIN
    -- Enable DBMS_OUTPUT
    DBMS_OUTPUT.ENABLE(1000000);
    
    SP_UPDATE_SALARY(
        1, -- Employee ID
        6000, -- New salary
        'Annual performance review increase',
        v_result
    );
    DBMS_OUTPUT.PUT_LINE(v_result);
END;
/

-- Test Department Report
