-- ----------------------------
-- Company Database Project
-- PL/SQL Procedures and Functions
-- ----------------------------

-- 1. FUNCTION: Calculate Employee Age
CREATE OR REPLACE FUNCTION FN_CALCULATE_AGE(p_dob DATE)
RETURN NUMBER
IS
    v_age NUMBER;
BEGIN
    v_age := FLOOR(MONTHS_BETWEEN(SYSDATE, p_dob) / 12);
    RETURN v_age;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END FN_CALCULATE_AGE;
/

-- 2. FUNCTION: Get Employee Total Working Hours
CREATE OR REPLACE FUNCTION FN_GET_EMPLOYEE_HOURS(p_emp_id NUMBER)
RETURN NUMBER
IS
    v_total_hours NUMBER := 0;
BEGIN
    SELECT NVL(SUM(HOURS_PER_WEEK), 0)
    INTO v_total_hours
    FROM WORK_ASSIGNMENT
    WHERE EMP_ID = p_emp_id;
    
    RETURN v_total_hours;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
    WHEN OTHERS THEN
        RETURN -1; -- Error indicator
END FN_GET_EMPLOYEE_HOURS;
/

-- 3. FUNCTION: Calculate Product Inventory Value
CREATE OR REPLACE FUNCTION FN_CALCULATE_INVENTORY_VALUE(p_product_id NUMBER, p_unit_price NUMBER DEFAULT 100)
RETURN NUMBER
IS
    v_total_quantity NUMBER := 0;
    v_inventory_value NUMBER := 0;
BEGIN
    SELECT NVL(SUM(QUANTITY), 0)
    INTO v_total_quantity
    FROM INVENTORY
    WHERE PRODUCT_ID = p_product_id;
    
    v_inventory_value := v_total_quantity * p_unit_price;
    RETURN v_inventory_value;
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END FN_CALCULATE_INVENTORY_VALUE;
/

-- 4. PROCEDURE: Add New Employee with Validation
CREATE OR REPLACE PROCEDURE SP_ADD_EMPLOYEE(
    p_name VARCHAR2,
    p_national_insurance_no VARCHAR2,
    p_address VARCHAR2,
    p_salary NUMBER,
    p_dob DATE,
    p_email VARCHAR2,
    p_phone VARCHAR2,
    p_dept_id NUMBER,
    p_super_id NUMBER,
    p_result OUT VARCHAR2
)
IS
    v_count NUMBER;
    v_emp_id NUMBER;
BEGIN
    -- Validate department exists
    SELECT COUNT(*)
    INTO v_count
    FROM DEPARTMENT
    WHERE DEPT_ID = p_dept_id;
    
    IF v_count = 0 THEN
        p_result := 'ERROR: Department does not exist';
        RETURN;
    END IF;
    
    -- Validate supervisor exists (if provided)
    IF p_super_id IS NOT NULL THEN
        SELECT COUNT(*)
        INTO v_count
        FROM SUPERVISOR
        WHERE SUPER_ID = p_super_id;
        
        IF v_count = 0 THEN
            p_result := 'ERROR: Supervisor does not exist';
            RETURN;
        END IF;
    END IF;
    
    -- Validate age (must be at least 18)
    IF FN_CALCULATE_AGE(p_dob) < 18 THEN
        p_result := 'ERROR: Employee must be at least 18 years old';
        RETURN;
    END IF;
    
    -- Validate salary (must be positive)
    IF p_salary <= 0 THEN
        p_result := 'ERROR: Salary must be positive';
        RETURN;
    END IF;
    
    -- Insert new employee
    INSERT INTO EMPLOYEE (
        NAME, NATIONAL_INSURANCE_NO, ADDRESS, SALARY, DOB,
        EMAIL_ADDRESS, PHONE_NO, DEPT_ID, SUPER_ID
    ) VALUES (
        p_name, p_national_insurance_no, p_address, p_salary, p_dob,
        p_email, p_phone, p_dept_id, p_super_id
    ) RETURNING EMP_ID INTO v_emp_id;
    
    COMMIT;
    p_result := 'SUCCESS: Employee added with ID: ' || v_emp_id;
    
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        ROLLBACK;
        p_result := 'ERROR: Duplicate National Insurance Number';
    WHEN OTHERS THEN
        ROLLBACK;
        p_result := 'ERROR: ' || SQLERRM;
END SP_ADD_EMPLOYEE;
/

-- 5. PROCEDURE: Update Employee Salary with History Log
CREATE OR REPLACE PROCEDURE SP_UPDATE_SALARY(
    p_emp_id NUMBER,
    p_new_salary NUMBER,
    p_reason VARCHAR2,
    p_result OUT VARCHAR2
)
IS
    v_old_salary NUMBER;
    v_emp_name VARCHAR2(100);
    v_count NUMBER;
BEGIN
    -- Check if employee exists
    SELECT COUNT(*)
    INTO v_count
    FROM EMPLOYEE
    WHERE EMP_ID = p_emp_id;
    
    IF v_count = 0 THEN
        p_result := 'ERROR: Employee not found';
        RETURN;
    END IF;
    
    -- Get current salary and name
    SELECT SALARY, NAME
    INTO v_old_salary, v_emp_name
    FROM EMPLOYEE
    WHERE EMP_ID = p_emp_id;
    
    -- Validate new salary
    IF p_new_salary <= 0 THEN
        p_result := 'ERROR: New salary must be positive';
        RETURN;
    END IF;
    
    -- Update salary
    UPDATE EMPLOYEE
    SET SALARY = p_new_salary
    WHERE EMP_ID = p_emp_id;
    
    -- Log the change (you could create a SALARY_HISTORY table for this)
    DBMS_OUTPUT.PUT_LINE('SALARY UPDATE LOG:');
    DBMS_OUTPUT.PUT_LINE('Employee: ' || v_emp_name || ' (ID: ' || p_emp_id || ')');
    DBMS_OUTPUT.PUT_LINE('Old Salary: ' || v_old_salary);
    DBMS_OUTPUT.PUT_LINE('New Salary: ' || p_new_salary);
    DBMS_OUTPUT.PUT_LINE('Reason: ' || p_reason);
    DBMS_OUTPUT.PUT_LINE('Date: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('----------------------------------------');
    
    COMMIT;
    p_result := 'SUCCESS: Salary updated from ' || v_old_salary || ' to ' || p_new_salary;
    
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        p_result := 'ERROR: ' || SQLERRM;
END SP_UPDATE_SALARY;
/

-- 6. PROCEDURE: Assign Employee to Project
CREATE OR REPLACE PROCEDURE SP_ASSIGN_TO_PROJECT(
    p_emp_id NUMBER,
    p_project_id NUMBER,
    p_hours_per_week NUMBER,
    p_result OUT VARCHAR2
)
IS
    v_count NUMBER;
    v_total_hours NUMBER;
    v_emp_name VARCHAR2(100);
    v_project_name VARCHAR2(100);
BEGIN
    -- Validate employee exists
    SELECT COUNT(*), MAX(NAME)
    INTO v_count, v_emp_name
    FROM EMPLOYEE
    WHERE EMP_ID = p_emp_id;
    
    IF v_count = 0 THEN
        p_result := 'ERROR: Employee not found';
        RETURN;
    END IF;
    
    -- Validate project exists
    SELECT COUNT(*), MAX(NAME)
    INTO v_count, v_project_name
    FROM PROJECT
    WHERE PROJECT_ID = p_project_id;
    
    IF v_count = 0 THEN
        p_result := 'ERROR: Project not found';
        RETURN;
    END IF;
    
    -- Check if already assigned
    SELECT COUNT(*)
    INTO v_count
    FROM WORK_ASSIGNMENT
    WHERE EMP_ID = p_emp_id AND PROJECT_ID = p_project_id;
    
    IF v_count > 0 THEN
        p_result := 'ERROR: Employee already assigned to this project';
        RETURN;
    END IF;
    
    -- Check total hours constraint (max 50 hours per week)
    v_total_hours := FN_GET_EMPLOYEE_HOURS(p_emp_id) + p_hours_per_week;
    
    IF v_total_hours > 50 THEN
        p_result := 'ERROR: Total weekly hours would exceed 50 hours limit';
        RETURN;
    END IF;
    
    -- Insert assignment
    INSERT INTO WORK_ASSIGNMENT (EMP_ID, PROJECT_ID, HOURS_PER_WEEK)
    VALUES (p_emp_id, p_project_id, p_hours_per_week);
    
    COMMIT;
    p_result := 'SUCCESS: ' || v_emp_name || ' assigned to ' || v_project_name || ' (' || p_hours_per_week || ' hours/week)';
    
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        p_result := 'ERROR: ' || SQLERRM;
END SP_ASSIGN_TO_PROJECT;
/

-- 7. PROCEDURE: Generate Department Report
CREATE OR REPLACE PROCEDURE SP_DEPARTMENT_REPORT(p_dept_id NUMBER)
IS
    CURSOR c_employees IS
        SELECT EMP_ID, NAME, SALARY, FN_CALCULATE_AGE(DOB) AS AGE,
               FN_GET_EMPLOYEE_HOURS(EMP_ID) AS WEEKLY_HOURS
        FROM EMPLOYEE
        WHERE DEPT_ID = p_dept_id
        ORDER BY SALARY DESC;
        
    v_dept_name VARCHAR2(100);
    v_manager_name VARCHAR2(100);
    v_total_employees NUMBER;
    v_total_payroll NUMBER;
    v_avg_salary NUMBER;
    v_avg_age NUMBER;
BEGIN
    -- Get department info
    SELECT d.NAME, e.NAME, COUNT(emp.EMP_ID), SUM(emp.SALARY), AVG(emp.SALARY), AVG(FN_CALCULATE_AGE(emp.DOB))
    INTO v_dept_name, v_manager_name, v_total_employees, v_total_payroll, v_avg_salary, v_avg_age
    FROM DEPARTMENT d
    LEFT JOIN EMPLOYEE e ON d.MANAGER_ID = e.EMP_ID
    LEFT JOIN EMPLOYEE emp ON d.DEPT_ID = emp.DEPT_ID
    WHERE d.DEPT_ID = p_dept_id
    GROUP BY d.NAME, e.NAME;
    
    -- Print report header
    DBMS_OUTPUT.PUT_LINE('==================================================');
    DBMS_OUTPUT.PUT_LINE('DEPARTMENT REPORT');
    DBMS_OUTPUT.PUT_LINE('==================================================');
    DBMS_OUTPUT.PUT_LINE('Department: ' || v_dept_name);
    DBMS_OUTPUT.PUT_LINE('Manager: ' || NVL(v_manager_name, 'Not Assigned'));
    DBMS_OUTPUT.PUT_LINE('Total Employees: ' || v_total_employees);
    DBMS_OUTPUT.PUT_LINE('Total Payroll: £' || TO_CHAR(v_total_payroll, '999,999,999.99'));
    DBMS_OUTPUT.PUT_LINE('Average Salary: £' || TO_CHAR(v_avg_salary, '999,999,999.99'));
    DBMS_OUTPUT.PUT_LINE('Average Age: ' || ROUND(v_avg_age, 1) || ' years');
    DBMS_OUTPUT.PUT_LINE('--------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('EMPLOYEE DETAILS:');
    DBMS_OUTPUT.PUT_LINE('--------------------------------------------------');
    
    -- Print employee details
    FOR emp_rec IN c_employees LOOP
        DBMS_OUTPUT.PUT_LINE(
            RPAD(emp_rec.NAME, 25) || ' | ' ||
            'Salary: £' || LPAD(TO_CHAR(emp_rec.SALARY, '999,999'), 10) || ' | ' ||
            'Age: ' || LPAD(emp_rec.AGE, 3) || ' | ' ||
            'Hours/Week: ' || LPAD(emp_rec.WEEKLY_HOURS, 3)
        );
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('==================================================');
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Department not found');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: ' || SQLERRM);
END SP_DEPARTMENT_REPORT;
/

-- 8. PROCEDURE: Bulk Update Inventory
CREATE OR REPLACE PROCEDURE SP_BULK_UPDATE_INVENTORY(
    p_warehouse VARCHAR2,
    p_adjustment_factor NUMBER, -- e.g., 1.1 for 10% increase
    p_result OUT VARCHAR2
)
IS
    v_rows_updated NUMBER;
BEGIN
    UPDATE INVENTORY
    SET QUANTITY = ROUND(QUANTITY * p_adjustment_factor)
    WHERE WAREHOUSE = p_warehouse;
    
    v_rows_updated := SQL%ROWCOUNT;
    
    COMMIT;
    p_result := 'SUCCESS: Updated ' || v_rows_updated || ' inventory records in ' || p_warehouse;
    
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        p_result := 'ERROR: ' || SQLERRM;
END SP_BULK_UPDATE_INVENTORY;
/
